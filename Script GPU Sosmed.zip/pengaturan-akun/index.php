<?php 
/* 
  Aplikasi Web Panel
  Build By Frendy Santoso
  WA : 0856 5400 8642
  YouTube : Frendy Santoso
  Panel : www.borneo-panel.com
  Blog : frendysantoso.blogspot.com
  IG : @frndysntoso
  
  !NOTE : Dilarang keras menghapus Copyright
*/
session_start();
require '../include/function.php';

if (!isset($_SESSION['username'])) {
  header("location:../../login");
  exit();
}

$username = $_SESSION['username'];
$qUser = mysqli_query($db, "SELECT * FROM user WHERE username = '$username'");
$fUser = mysqli_fetch_assoc($qUser);

if (isset($_POST['simpan'])) {
  $passwordL = mysqli_real_escape_string($db, $_POST['passwordL']);
  $passwordB = mysqli_real_escape_string($db, $_POST['passwordB']);
  $passwordBk = mysqli_real_escape_string($db, $_POST['passwordBk']);

  if (empty($passwordL) OR empty($passwordB) OR empty($passwordBk)) {
    alert('gagal', 'Masih ada data yang kosong', 'pengaturan-akun');
  } else {
    if (password_verify($passwordL, $fUser['password'])) {
      if ($passwordB === $passwordBk) {
        $passwordBHash = password_hash($passwordB, PASSWORD_DEFAULT);
        mysqli_query($db, "UPDATE user SET password = '$passwordBHash' WHERE username = '$username'");
        alert('berhasil', 'Password baru berhasil di simpan', 'pengaturan-akun');
      } else {
        alert('gagal', 'Konfirmasi password tidak sesuai', 'pengaturan-akun');
      }
    } else {
      alert('gagal', 'Password lama tidak sesuai', 'pengaturan-akun');
    }
  }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Pengaturan Akun - <?= $judul; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>
	
	<!-- Fonts and icons -->
	<script src="../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/atlantis.min.css">
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php require '../include/menu.php'; ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Pengaturan Akun</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?= $link; ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								Pengaturan Akun
							</li>
						</ul>
					</div>
					<div class="row justify-content-center">
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Pengaturan Akun</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<?php if (isset($_COOKIE['berhasil'])): ?>
							                  <div class="alert alert-success">
							                    <?= $_COOKIE['berhasil']; ?>
							                  </div>
							                  <?php endif ?>
							                  <?php if (isset($_COOKIE['gagal'])): ?>
							                  <div class="alert alert-danger">
							                    <?= $_COOKIE['gagal']; ?>
							                  </div>
							                  <?php endif ?>
											<form action="" method="POST">
												<div class="form-group">
							                      <label>Password Lama</label>
							                      <input type="password" class="form-control" name="passwordL">
							                    </div>
							                    <div class="form-group">
							                      <label>Password Baru</label>
							                      <input type="password" class="form-control" name="passwordB">
							                    </div>
							                    <div class="form-group">
							                      <label>Ulangi Password Baru</label>
							                      <input type="password" class="form-control" name="passwordBk">
							                    </div>
												<div class="text-right">
													<button class="btn btn-default" type="reset">Batal</button>
													<button class="btn btn-primary" type="submit" name="simpan">Simpan</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php require '../include/footer.php'; ?>
		</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../assets/js/core/popper.min.js"></script>
	<script src="../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Atlantis JS -->
	<script src="../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../assets/js/setting-demo2.js"></script>
</body>
</html>