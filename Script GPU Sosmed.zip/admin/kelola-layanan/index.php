<?php 
/* 
  Aplikasi Web Panel
  Build By Frendy Santoso
  WA : 0856 5400 8642
  YouTube : Frendy Santoso
  Panel : www.borneo-panel.com
  Blog : frendysantoso.blogspot.com
  IG : @frndysntoso
  
  !NOTE : Dilarang keras menghapus Copyright
*/
session_start();
require '../../include/function.php';

if (!isset($_SESSION['username'])) {
  header("location:../../login");
  exit();
}

$username = $_SESSION['username'];
$qUser = mysqli_query($db, "SELECT * FROM user WHERE username = '$username'");
$fUser = mysqli_fetch_assoc($qUser);

if ($fUser['level'] !== "Admin") {
  header("location:../../logout");
  exit();
}

if (isset($_POST['tombol_tambah'])) {
  $layanan = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['layanan'])));
  $kategori = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['kategori'])));
  $harga = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['harga'])));
  $min = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['min'])));
  $max = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['max'])));
  $provider_id = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['provider_id'])));

  if (empty($layanan) OR empty($kategori) OR empty($harga) OR empty($min) OR empty($max) OR empty($provider_id)) {
    alert('gagal', 'Masih ada data yang kosong', 'kelola-layanan');
  } else {
    mysqli_query($db, "INSERT INTO service VALUES ('','$layanan','$kategori','$harga','$min','$max','$provider_id')");
    alert('berhasil', 'Layanan baru berhasil di tambahkan', 'kelola-layanan');
  }

}

if (isset($_POST['tombol_ambil'])) {

  require '../../include/data-api.php';

  class API {

      public $api_url = 'https://borneopanel.com/api/'; // API Url Borneo Panel API
      
      public function service($api_key, $user_key, $jenis) {
          return json_decode($this->connect($this->api_url, array(
              'api' => $api_key,
              'user' => $user_key,
              'action' => 'service',
              'jenis' => $jenis
          )), true);
      }

      private function connect($url, $post) {
          $_post = Array();
          if (is_array($post)) {
              foreach ($post as $name => $value) {
                  $_post[] = $name.'='.urlencode($value);
              }
          }
          $ch = curl_init($url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch, CURLOPT_POST, 1);
          curl_setopt($ch, CURLOPT_HEADER, 0);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
          if (is_array($post)) {
              curl_setopt($ch, CURLOPT_POSTFIELDS, join('&', $_post));
          }
          curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
          $result = curl_exec($ch);
          if (curl_errno($ch) != 0 && empty($result)) {
              $result = false;
          }
          curl_close($ch);
          return $result;
      }
  }

  $api = new API();

  $service = $api->service($api_key, $user_key, 'sosmed');
  if ($service['result'] === "success") {
    mysqli_query($db, "TRUNCATE TABLE service");
    foreach ($service['response'] as $layanan) {
        $idS = $layanan['id'];
        $service = $layanan['service'];
        $category = $layanan['category'];
        $harga = $layanan['harga'];
        $min = $layanan['min'];
        $max = $layanan['max'];
        $note = $layanan['note'];
        mysqli_query($db, "INSERT INTO service VALUES ('','$service','$category','$harga','$min','$max','$idS')");
    }
    alert('berhasil', 'Pengambilan layanan borneo panel berhasil', 'kelola-layanan');
  } else {
    alert('gagal', 'API Key gagal terhubung ke server BP', 'kelola-layanan');
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Kelola Layanan - <?= $judul; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../../assets/img/icon.ico" type="image/x-icon"/>
	
	<!-- Fonts and icons -->
	<script src="../../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../assets/css/atlantis.min.css">
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php require '../../include/menu.php'; ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Kelola Layanan</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?= $link; ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								Kelola Layanan
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Kelola Layanan</h4>
								</div>
								<div class="card-body">
									<?php if (isset($_COOKIE['gagal'])): ?>
					                <div class="alert alert-danger">
					                  <?= $_COOKIE['gagal']; ?>
					                </div>
					                <?php endif ?>
					                <?php if (isset($_COOKIE['berhasil'])): ?>
					                <div class="alert alert-success">
					                  <?= $_COOKIE['berhasil']; ?>
					                </div>
					                <?php endif ?>
					                <div class="row">
					                  <div class="col-md-6">
					                    <button class="btn btn-primary btn-block" style="margin-bottom: 10px;" id="btn-ambil-layanan">
					                      Get Layanan
					                    </button>
					                  </div>
					                  <div class="col-md-6">
					                    <button class="btn btn-primary btn-block" id="btn-tambah-layanan">
					                      Tambah Layanan
					                    </button>
					                  </div>
					                </div>
					                <hr>
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
						                  <tr>
						                    <th>No</th>
						                    <th>ID</th>
						                    <th>Layanan</th>
						                    <th>Kategori</th>
						                    <th>Harga</th>
						                    <th>Min</th>
						                    <th>Max</th>
						                  </tr>
						                  </thead>
						                  <tbody>
						                    <?php 
						                    $qRi = mysqli_query($db, "SELECT * FROM service ORDER BY kategori DESC");
						                    $no = 1;
						                    while ($fRi = mysqli_fetch_assoc($qRi)) :
						                    ?>
						                    <tr>
						                      <td><?= $no; ?></td>
						                      <td><?= $fRi['provider_id']; ?></td>
						                      <td><?= $fRi['layanan']; ?></td>
						                      <td><?= $fRi['kategori']; ?></td>
						                      <td><?= number_format($fRi['harga'],0,',','.'); ?></td>
						                      <td><?= number_format($fRi['min'],0,',','.'); ?></td>
						                      <td><?= number_format($fRi['max'],0,',','.'); ?></td>
						                    </tr>
						                    <?php $no++; endwhile; ?>
						                  </tbody>
							            </table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php require '../../include/footer.php'; ?>
		</div>
		
	</div>

	<div class="modal fade" id="tambahlayanan">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Tambah Layanan</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST">
        <div class="modal-body">
          <div class="form-group">
            <label>Layanan</label>
            <input type="text" class="form-control" name="layanan">
          </div>
          <div class="form-group">
            <label>Kategori</label>
            <input type="text" class="form-control" name="kategori">
          </div>
          <div class="form-group">
            <label>Harga</label>
            <input type="number" class="form-control" name="harga">
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label>Min</label>
                <input type="number" class="form-control" name="min">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Max</label>
                <input type="number" class="form-control" name="max">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label>Provider ID</label>
            <input type="number" class="form-control" name="provider_id">
          </div>
        </div>
        <div class="modal-footer text-right">
          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
          <button type="submit" name="tombol_tambah" class="btn btn-primary">Tambah Layanan</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<div class="modal fade" id="ambil_layanan">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Get Layanan</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST">
        <div class="modal-body">
          <p>Ingin mengambil layanan Borneo Panel? Layanan sekarang akan dihapus dan di gantikan dengan semua layanan Borneo Panel.</p>
        </div>
        <div class="modal-footer text-right">
          <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
          <button type="submit" name="tombol_ambil" class="btn btn-primary">Tetap Ambil</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

	<!--   Core JS Files   -->
	<script src="../../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../../assets/js/core/popper.min.js"></script>
	<script src="../../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Datatables -->
	<script src="../../assets/js/plugin/datatables/datatables.min.js"></script>
	<!-- Atlantis JS -->
	<script src="../../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../../assets/js/setting-demo2.js"></script>
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});

			$('#multi-filter-select').DataTable( {
				"pageLength": 5,
				initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						var select = $('<select class="form-control"><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
								);

							column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
						} );

						column.data().unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			});

			// Add Row
			$('#add-row').DataTable({
				"pageLength": 5,
			});

			var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

			$('#addRowButton').click(function() {
				$('#add-row').dataTable().fnAddData([
					$("#addName").val(),
					$("#addPosition").val(),
					$("#addOffice").val(),
					action
					]);
				$('#addRowModal').modal('hide');

			});
		});
		  $("#btn-tambah-layanan").on('click', function() {
		    $("#tambahlayanan").modal('show');
		  });
		  $("#btn-ambil-layanan").on('click', function() {
		    $("#ambil_layanan").modal('show');
		  });
	</script>
</body>
</html>