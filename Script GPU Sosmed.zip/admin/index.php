<?php 
	header("location:../");
	exit();
?>