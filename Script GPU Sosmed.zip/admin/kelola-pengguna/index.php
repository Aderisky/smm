<?php 
/* 
  Aplikasi Web Panel
  Build By Frendy Santoso
  WA : 0856 5400 8642
  YouTube : Frendy Santoso
  Panel : www.borneo-panel.com
  Blog : frendysantoso.blogspot.com
  IG : @frndysntoso
  
  !NOTE : Dilarang keras menghapus Copyright
*/
session_start();
require '../../include/function.php';

if (!isset($_SESSION['username'])) {
  header("location:../../login");
  exit();
}

$username = $_SESSION['username'];
$qUser = mysqli_query($db, "SELECT * FROM user WHERE username = '$username'");
$fUser = mysqli_fetch_assoc($qUser);

if ($fUser['level'] !== "Admin") {
  header("location:../../logout");
  exit();
}

if (isset($_POST['tombol_tambah'])) {
  $p_username = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['username'])));
  $p_password = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['password'])));
  $p_level = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['level'])));
  $p_saldo = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['saldo'])));
  $p_nohp = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['nohp'])));

  $password_hash = password_hash($p_password, PASSWORD_DEFAULT);

  if (empty($p_username) OR empty($p_password) OR empty($p_level) OR empty($p_saldo) OR empty($p_nohp)) {
    alert('gagal', 'Masih ada data yang kosong', 'kelola-pengguna');
  } else {
    $qUsername = mysqli_query($db, "SELECT * FROM user WHERE username = '$p_username'");
    if (mysqli_num_rows($qUsername) === 0 ) {
      mysqli_query($db, "INSERT INTO user VALUES ('','$p_username','$password_hash','$p_level','$p_saldo','0','$p_nohp','On','$tanggal $waktu')");
      alert('berhasil', 'Pengguna baru berhasil di tambahkan dengan username : ' . $p_username . ' dan password : ' . $p_password, 'kelola-pengguna');
    } else {
      alert('gagal', 'Username sudah digunakan', 'kelola-pengguna');
    }
  }

}

if (isset($_GET['id']) AND isset($_GET['aksi'])) {
  $aksi = $_GET['aksi'];
  $id = $_GET['id'];

  mysqli_query($db, "UPDATE user SET status = '$aksi' WHERE id = '$id'");
  alert('berhasil', 'Status pengguna berhasil di update', 'kelola-pengguna');

}

if (isset($_GET['hapus'])) {
  $idHapus = $_GET['hapus'];
  mysqli_query($db, "DELETE FROM user WHERE id = '$idHapus'");
  alert('berhasil', 'Pengguna berhasil di hapus', 'kelola-pengguna');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Kelola Pengguna - <?= $judul; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../../assets/img/icon.ico" type="image/x-icon"/>
	
	<!-- Fonts and icons -->
	<script src="../../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../assets/css/atlantis.min.css">
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php require '../../include/menu.php'; ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Kelola Pengguna</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?= $link; ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								Kelola Pengguna
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Kelola Pengguna</h4>
								</div>
								<div class="card-body">
									<?php if (isset($_COOKIE['gagal'])): ?>
					                <div class="alert alert-danger">
					                  <?= $_COOKIE['gagal']; ?>
					                </div>
					                <?php endif ?>
					                <?php if (isset($_COOKIE['berhasil'])): ?>
					                <div class="alert alert-success">
					                  <?= $_COOKIE['berhasil']; ?>
					                </div>
					                <?php endif ?>
					                <div class="row">
					                  <div class="col-md-12">
					                    <button class="btn btn-info btn-block" style="margin-bottom: 10px;" id="btn-tambah-pengguna">
					                      Tambah Pengguna
					                    </button>
					                  </div>
					                </div>
					                <hr>
									<div class="table-responsive">
										<table id="basic-datatables" class="display table table-striped table-hover" >
											<thead>
							                  <tr>
							                    <th>No</th>
							                    <th>Username</th>
							                    <th>Level</th>
							                    <th>Saldo</th>
							                    <th>Saldo Terpakai</th>
							                    <th>No HP</th>
							                    <th>Status</th>
							                    <th>Tgl Register</th>
							                    <th>Aksi</th>
							                  </tr>
							                  </thead>
							                  <tbody>
							                    <?php 
							                    $qRi = mysqli_query($db, "SELECT * FROM user ORDER BY id DESC");
							                    $no = 1;
							                    while ($fRi = mysqli_fetch_assoc($qRi)) :
							                    ?>
							                    <tr>
							                      <td><?= $no; ?></td>
							                      <td><?= $fRi['username']; ?></td>
							                      <td><?= $fRi['level']; ?></td>
							                      <td><?= number_format($fRi['saldo'],0,',','.'); ?></td>
							                      <td><?= number_format($fRi['saldo_terpakai'],0,',','.'); ?></td>
							                      <td><?= $fRi['nohp']; ?></td>
							                      <td>
							                        <?php if ($fRi['status'] === "On"): ?>
							                          <span class="badge badge-success">Aktif</span>
							                        <?php else : ?>
							                          <span class="badge badge-danger">Non Aktif</span>
							                        <?php endif ?>
							                      </td>
							                      <td><?= $fRi['tgl_reg']; ?></td>
							                      <td>
							                        <?php if ($fRi['status'] === "On"): ?>
							                          <a href="?aksi=Off&id=<?= $fRi['id']; ?>" class="badge badge-danger">Non Aktifkan</a>
							                        <?php else : ?>
							                          <a href="?aksi=On&id=<?= $fRi['id']; ?>" class="badge badge-success">Aktifkan</a>
							                        <?php endif ?>
							                        <a href="?hapus=<?= $fRi['id']; ?>" class="badge badge-danger">Hapus</a>
							                      </td>
							                    </tr>
							                    <?php $no++; endwhile; ?>
							                  </tbody>
							              </table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php require '../../include/footer.php'; ?>
		</div>
		
	</div>
	
	<div class="modal fade" id="form-pengguna">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h4 class="modal-title">Tambah Pengguna</h4>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <form action="" method="POST">
	        <div class="modal-body">
	          <div class="form-group">
	            <label>Username</label>
	            <input type="text" class="form-control" name="username">
	          </div>
	          <div class="form-group">
	            <label>Password</label>
	            <input type="text" class="form-control" name="password">
	          </div>
	          <div class="form-group">
	            <label>Level</label>
	            <select name="level" id="level" class="form-control">
	              <option value="0">Pilih salah satu</option>
	              <option value="Admin">Admin</option>
	              <option value="Member">Member</option>
	            </select>
	          </div>
	          <div class="form-group">
	            <label>Saldo</label>
	            <input type="number" class="form-control" name="saldo">
	          </div>
	          <div class="form-group">
	            <label>No HP</label>
	            <input type="number" class="form-control" name="nohp">
	          </div>
	        </div>
	        <div class="modal-footer text-right">
	          <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
	          <button type="submit" name="tombol_tambah" class="btn btn-primary">Tambah Pengguna</button>
	        </div>
	      </form>
	    </div>
	    <!-- /.modal-content -->
	  </div>
	  <!-- /.modal-dialog -->
	</div>
	<!-- /.modal -->

	<!--   Core JS Files   -->
	<script src="../../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../../assets/js/core/popper.min.js"></script>
	<script src="../../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Datatables -->
	<script src="../../assets/js/plugin/datatables/datatables.min.js"></script>
	<!-- Atlantis JS -->
	<script src="../../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../../assets/js/setting-demo2.js"></script>
	<script >
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
			});

			$('#multi-filter-select').DataTable( {
				"pageLength": 5,
				initComplete: function () {
					this.api().columns().every( function () {
						var column = this;
						var select = $('<select class="form-control"><option value=""></option></select>')
						.appendTo( $(column.footer()).empty() )
						.on( 'change', function () {
							var val = $.fn.dataTable.util.escapeRegex(
								$(this).val()
								);

							column
							.search( val ? '^'+val+'$' : '', true, false )
							.draw();
						} );

						column.data().unique().sort().each( function ( d, j ) {
							select.append( '<option value="'+d+'">'+d+'</option>' )
						} );
					} );
				}
			});

			// Add Row
			$('#add-row').DataTable({
				"pageLength": 5,
			});

			var action = '<td> <div class="form-button-action"> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

			$('#addRowButton').click(function() {
				$('#add-row').dataTable().fnAddData([
					$("#addName").val(),
					$("#addPosition").val(),
					$("#addOffice").val(),
					action
					]);
				$('#addRowModal').modal('hide');

			});
		});
		$("#btn-tambah-pengguna").on('click', function() {
		    $("#form-pengguna").modal('show');
		  });
	</script>
</body>
</html>