<?php 
/* 
  Aplikasi Web Panel
  Build By Frendy Santoso
  WA : 0856 5400 8642
  YouTube : Frendy Santoso
  Panel : www.borneo-panel.com
  Blog : frendysantoso.blogspot.com
  IG : @frndysntoso
  
  !NOTE : Dilarang keras menghapus Copyright
*/
session_start();
require '../../include/function.php';
require '../../include/data-api.php';
require '../../include/data-panel.php';
require '../../include/data-db.php';

if (!isset($_SESSION['username'])) {
  header("location:../../login");
  exit();
}

function cek($cek) {
	global $hal_db;
	if ($hal_db === $cek) {
		return 'checked="checked"';
	}
}

$username = $_SESSION['username'];
$qUser = mysqli_query($db, "SELECT * FROM user WHERE username = '$username'");
$fUser = mysqli_fetch_assoc($qUser);

if ($fUser['level'] !== "Admin") {
  header("location:../../logout");
  exit();
}

if (isset($_POST['tombol_api'])) {
  $api_key = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['api_key'])));
  $user_key = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['user_key'])));

  $isi = '<?php
$api_key = "'.$api_key.'";
$user_key = "'.$user_key.'";
?>';

  $handle = fopen('../../include/data-api.php', 'w');
  fwrite($handle, $isi);

  alert('berhasil_api', 'Data Api berhasil di perbahrui', 'konfigurasi-panel');

}

if (isset($_POST['tombol_db'])) {
  $password_db = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['password_db'])));
  $hal_db = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['hal_db'])));

  $isi = '<?php
$password_db = "'.$password_db.'";
$hal_db = "'.$hal_db.'";
?>';

  $handle = fopen('../../include/data-db.php', 'w');
  fwrite($handle, $isi);

  alert('berhasil_db', 'Informasi Database berhasil di perbahrui', 'konfigurasi-panel');

}

if (isset($_POST['tombol_info'])) {
  $judul = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['judul'])));

  $isi = '<?php
$judul = "'.$judul.'";
?>';

  $handle = fopen('../../include/data-panel.php', 'w');
  fwrite($handle, $isi);

  alert('berhasil_info', 'Data panel berhasil di perbahrui', 'konfigurasi-panel');

}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Konfigurasi Panel - <?= $judul; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../../assets/img/icon.ico" type="image/x-icon"/>
	
	<!-- Fonts and icons -->
	<script src="../../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../assets/css/atlantis.min.css">
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php require '../../include/menu.php'; ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Konfigurasi Panel</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?= $link; ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								Konfigurasi Panel
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Data Panel</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<?php if (isset($_COOKIE['berhasil_info'])): ?>
							                  <div class="alert alert-success">
							                    <?= $_COOKIE['berhasil_info']; ?>
							                  </div>
							                  <?php endif ?>
							                  <?php if (isset($_COOKIE['gagal_info'])): ?>
							                  <div class="alert alert-danger">
							                    <?= $_COOKIE['gagal_info']; ?>
							                  </div>
							                  <?php endif ?>
											<form action="" method="POST">
												<div class="form-group">
							                      <label>Nama Panel</label>
							                      <input type="text" class="form-control" value="<?= $judul; ?>" name="judul">
							                    </div>
												<div class="text-right">
													<button class="btn btn-default" type="reset">Batal</button>
													<button class="btn btn-primary" type="submit" name="tombol_info">Simpan</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Data Api</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<?php if (isset($_COOKIE['berhasil_api'])): ?>
							                  <div class="alert alert-success">
							                    <?= $_COOKIE['berhasil_api']; ?>
							                  </div>
							                  <?php endif ?>
							                  <?php if (isset($_COOKIE['gagal_api'])): ?>
							                  <div class="alert alert-danger">
							                    <?= $_COOKIE['gagal_api']; ?>
							                  </div>
							                  <?php endif ?>
											<form action="" method="POST">
												<div class="form-group">
								                    <label>Api Key</label>
								                    <input type="text" class="form-control" name="api_key" value="<?= $api_key; ?>">
								                  </div>
								                  <div class="form-group">
								                    <label>User Key</label>
								                    <input type="text" class="form-control" name="user_key" value="<?= $user_key; ?>">
								                  </div>
												<div class="text-right">
													<button class="btn btn-default" type="reset">Batal</button>
													<button class="btn btn-primary" type="submit" name="tombol_api">Simpan</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Database</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<?php if (isset($_COOKIE['berhasil_db'])): ?>
							                  <div class="alert alert-success">
							                    <?= $_COOKIE['berhasil_db']; ?>
							                  </div>
							                  <?php endif ?>
							                  <?php if (isset($_COOKIE['gagal_api'])): ?>
							                  <div class="alert alert-danger">
							                    <?= $_COOKIE['gagal_api']; ?>
							                  </div>
							                  <?php endif ?>
											<form action="" method="POST">
												<div class="form-group">
								                    <label>Password</label>
								                    <input type="text" class="form-control" name="password_db" value="<?= $password_db; ?>">
								                  </div>
								                  <div class="form-group">
													<label class="form-label">Status Halaman</label>
													<div class="selectgroup w-100">
														<label class="selectgroup-item">
															<input type="radio" name="hal_db" value="on" class="selectgroup-input" <?= cek('on'); ?>>
															<span class="selectgroup-button">Tampilakan</span>
														</label>
														<label class="selectgroup-item">
															<input type="radio" name="hal_db" value="off" class="selectgroup-input" <?= cek('off'); ?>>
															<span class="selectgroup-button">Sembunyikan</span>
														</label>
													</div>
												</div>
												<div class="text-right">
													<button class="btn btn-default" type="reset">Batal</button>
													<button class="btn btn-primary" type="submit" name="tombol_db">Simpan</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php require '../../include/footer.php'; ?>
		</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../../assets/js/core/popper.min.js"></script>
	<script src="../../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Atlantis JS -->
	<script src="../../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../../assets/js/setting-demo2.js"></script>
</body>
</html>