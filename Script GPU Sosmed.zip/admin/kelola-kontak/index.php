<?php 
/* 
  Aplikasi Web Panel
  Build By Frendy Santoso
  WA : 0856 5400 8642
  YouTube : Frendy Santoso
  Panel : www.borneo-panel.com
  Blog : frendysantoso.blogspot.com
  IG : @frndysntoso
  
  !NOTE : Dilarang keras menghapus Copyright
*/
session_start();
require '../../include/function.php';

if (!isset($_SESSION['username'])) {
  header("location:../../login");
  exit();
}

$username = $_SESSION['username'];
$qUser = mysqli_query($db, "SELECT * FROM user WHERE username = '$username'");
$fUser = mysqli_fetch_assoc($qUser);

if ($fUser['level'] !== "Admin") {
  header("location:../../logout");
  exit();
}

if (isset($_POST['tombol'])) {
  $nama = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['nama'])));
  $jabatan = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['jabatan'])));
  $wa = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['wa'])));
  $ig = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['ig'])));
  $fb = htmlspecialchars(trim(mysqli_real_escape_string($db, $_POST['fb'])));

  if (empty($nama) OR empty($jabatan)) {
    alert('gagal', 'Masih ada data yang kosong', 'kelola-kontak');
  } else {
    mysqli_query($db, "INSERT INTO kontak VALUES ('','$nama','$jabatan','$wa','$ig','$fb')");
    alert('berhasil','Kontak baru berhasil di tambahkan','kelola-kontak');
  }

}

if (isset($_GET['hapus'])) {
  $idHapus = $_GET['hapus'];
  mysqli_query($db, "DELETE FROM kontak WHERE id = '$idHapus'");
  alert('berhasil','Kontak berhasil di hapus', 'kelola-kontak');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Kelola Kontak - <?= $judul; ?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="../../assets/img/icon.ico" type="image/x-icon"/>
	
	<!-- Fonts and icons -->
	<script src="../../assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['../../assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>

	<!-- CSS Files -->
	<link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../../assets/css/atlantis.min.css">
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<link rel="stylesheet" href="../../assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php require '../../include/menu.php'; ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Kelola Kontak</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="<?= $link; ?>">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								Kelola Kontak
							</li>
						</ul>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Kelola Kontak</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12">
											<?php if (isset($_COOKIE['berhasil'])): ?>
							                  <div class="alert alert-success">
							                    <?= $_COOKIE['berhasil']; ?>
							                  </div>
							                  <?php endif ?>
							                  <?php if (isset($_COOKIE['gagal'])): ?>
							                  <div class="alert alert-danger">
							                    <?= $_COOKIE['gagal']; ?>
							                  </div>
							                  <?php endif ?>
											<form action="" method="POST">
												<div class="alert alert-warning">
								                    <strong>Informasi</strong> Untuk Nama & Jabatan wajib di isi, untuk Whatsapp, Instagram & Facebook boleh di isi boleh dikosongkan.
								                  </div>
								                  <div class="form-group">
								                    <label>Nama</label>
								                    <input type="text" class="form-control" name="nama">
								                  </div>
								                  <div class="form-group">
								                    <label>Jabatan</label>
								                    <input type="text" class="form-control" name="jabatan">
								                  </div>
								                  <div class="form-group">
								                    <label>Whatsapp</label>
								                    <div class="input-group mb-3">
								                      <div class="input-group-prepend">
								                        <span class="input-group-text">(+62)</span>
								                      </div>
								                      <input type="text" class="form-control" name="wa" placeholder="85654xxxx">
								                    </div>
								                  </div>
								                  <div class="form-group">
								                    <label>Instagram</label>
								                    <div class="input-group mb-3">
								                      <div class="input-group-prepend">
								                        <span class="input-group-text">http://instagram.com/</span>
								                      </div>
								                      <input type="text" class="form-control" name="ig">
								                    </div>
								                  </div>
								                  <div class="form-group">
								                    <label>Facebook</label>
								                    <div class="input-group mb-3">
								                      <div class="input-group-prepend">
								                        <span class="input-group-text">http://facebook.com/</span>
								                      </div>
								                      <input type="text" class="form-control" name="fb">
								                    </div>
								                  </div>
												<div class="text-right">
													<button class="btn btn-default" type="reset">Batal</button>
													<button class="btn btn-primary" type="submit" name="tombol">Tambah Kontak</button>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Informasi</div>
								</div>
								<div class="card-body">
									<div class="row">
										<div class="col-md-12" style="overflow: auto;">
											<table class="table table-bordered">
							                  <tr>
							                    <th>No</th>
							                    <th>Nama</th>
							                    <th>Jabatan</th>
							                    <th>Whatsapp</th>
							                    <th>Instagram</th>
							                    <th>Facebook</th>
							                    <th>Aksi</th>
							                  </tr>
							                  <?php 
							                  $no = 1;
							                  $qKontak = mysqli_query($db, "SELECT * FROM kontak ORDER BY id DESC");
							                  while ($qFetch = mysqli_fetch_assoc($qKontak)) :
							                  ?>
							                  <tr>
							                    <td><?= $no; ?></td>
							                    <td><?= $qFetch['nama']; ?></td>
							                    <td><?= $qFetch['jabatan']; ?></td>
							                    <td><?= $qFetch['whatsapp']; ?></td>
							                    <td><?= $qFetch['instagram']; ?></td>
							                    <td><?= $qFetch['facebook']; ?></td>
							                    <th>
							                      <a href="?hapus=<?= $qFetch['id']; ?>" class="badge badge-danger">
							                        <i class="fa fa-trash"></i>
							                      </a>
							                    </th>
							                  </tr>
							                  <?php $no++; endwhile; ?>
							                  <?php if (mysqli_num_rows($qKontak) === 0 ): ?>
							                  <tr>
							                    <td colspan="6" align="center">Kontak tidak di temukan</td>
							                  </tr>
							                  <?php endif ?>
							                </table>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php require '../../include/footer.php'; ?>
		</div>
	</div>
	<!--   Core JS Files   -->
	<script src="../../assets/js/core/jquery.3.2.1.min.js"></script>
	<script src="../../assets/js/core/popper.min.js"></script>
	<script src="../../assets/js/core/bootstrap.min.js"></script>
	<!-- jQuery UI -->
	<script src="../../assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
	<script src="../../assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>
	
	<!-- jQuery Scrollbar -->
	<script src="../../assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
	<!-- Atlantis JS -->
	<script src="../../assets/js/atlantis.min.js"></script>
	<!-- Atlantis DEMO methods, don't include it in your project! -->
	<script src="../../assets/js/setting-demo2.js"></script>
</body>
</html>