<?php 
require '../include/function.php';
require '../include/data-db.php';
if ($hal_db === "off") {
	require '../404.shtml';
	die();
} else {
	$tanyapassword = true;
}
if (isset($_POST['simpan'])) {
	$localhost = htmlspecialchars(trim($_POST['localhost']));
	$username = htmlspecialchars(trim($_POST['username']));
	$password = htmlspecialchars(trim($_POST['password']));
	$database = htmlspecialchars(trim($_POST['database']));
	$link = htmlspecialchars(trim($_POST['link']));

	$isi = '<?php
	$db = mysqli_connect("'.$localhost.'", "'.$username.'", "'.$password.'", "'.$database.'");
	$link = "'.$link.'";
	$localhost = "'.$localhost.'";
	$username = "'.$username.'";
	$password = "'.$password.'";
	$database = "'.$database.'";
	?>';

  $handle = fopen('../include/data-config.php', 'w');
  fwrite($handle, $isi);

  alert('berhasil', 'Data Api berhasil di perbahrui', 'db');

}

if (isset($_POST['minta_password'])) {
	$key = $_POST['key'];
	if ($key === $password_db) {
		$boleh = true;
	} else {
		echo "Password anda salah silahkan tingalkan halaman ini";
	}
}
?>

<?php if (isset($tanyapassword) AND !isset($boleh) AND !isset($_COOKIE['berhasil'])): ?>
<form action="" method="post">
	<input type="password" placeholder="Password Anda?" name="key">
	<button type="submit" name="minta_password">Submit</button>
</form>
<?php endif ?>



<?php if (isset($boleh) OR isset($_COOKIE['berhasil'])): ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Settings Database - <?= $judul; ?></title>
</head>
<body>
	<h1>Selamat datang</h1>
	<p>Dihalaman Control Panel Database</p>
	<?php if (isset($_COOKIE['berhasil'])): ?>
	<p style="color: green;">&check; &nbsp;Data sistem panel berhasil di simpan</p>
	<?php endif ?>
	<form action="" method="POST">
		<table>
			<tr>
				<td>Localhost</td>
				<td>:</td>
				<td><input type="text" name="localhost" value="<?= $localhost; ?>"></td>
			</tr>
			<tr>
				<td>Username</td>
				<td>:</td>
				<td><input type="text" name="username" value="<?= $username; ?>"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:</td>
				<td><input type="text" name="password" value="<?= $password; ?>"></td>
			</tr>
			<tr>
				<td>Database</td>
				<td>:</td>
				<td><input type="text" name="database" value="<?= $database; ?>"></td>
			</tr>
			<tr>
				<td>Link Halaman</td>
				<td>:</td>
				<td><input type="text" name="link" value="<?= $link; ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td align="right"><button type="submit" name="simpan">Simpan</button></td>
			</tr>
		</table>
	</form>
</body>
</html>
<?php endif ?>