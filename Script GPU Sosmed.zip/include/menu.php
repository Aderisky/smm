		<div class="main-header">
			<!-- Logo Header -->
			<div class="logo-header" data-background-color="blue">
				
				<a href="index.html" class="logo">
					<strong style="color: white;"><i class="fa fa-shopping-cart"></i> &nbsp; <?= $judul; ?></strong>
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
				<div class="nav-toggle">
					<button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="blue2">
				
				<div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item dropdown hidden-caret">
							<a class="dropdown-toggle profile-pic" data-toggle="dropdown" href="#" aria-expanded="false">
								<div class="avatar-sm">
									<img src="<?= $link; ?>/assets/img/profile.jpeg" alt="..." class="avatar-img rounded-circle">
								</div>
							</a>
							<ul class="dropdown-menu dropdown-user animated fadeIn">
								<div class="dropdown-user-scroll scrollbar-outer">
									<li>
										<a class="dropdown-item" href="<?= $link; ?>/pengaturan-akun">Pengaturan Akun</a>
										<a class="dropdown-item" href="<?= $link; ?>/logout">Logout</a>
									</li>
								</div>
							</ul>
						</li>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<div class="sidebar sidebar-style-2" data-background-color="dark2">
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2">
							<img src="<?= $link; ?>/assets/img/profile.jpeg" alt="..." class="avatar-img rounded-circle">
						</div>
						<div class="info">
							<a>
								<span>
									<?= $username; ?>
									<span class="user-level"><?= $fUser['level']; ?></span>
								</span>
							</a>	
						</div>
					</div>
					<ul class="nav nav-primary">
						<li class="nav-item">
							<a href="<?= $link; ?>">
								<i class="fas fa-home"></i>
								<p>Dashbord</p>
							</a>
						</li>
						<li class="nav-item">
							<a data-toggle="collapse" href="#dashboard" class="collapsed" aria-expanded="false">
								<i class="fas fa-star"></i>
								<p>Fitur Admin</p>
								<span class="caret"></span>
							</a>
							<div class="collapse" id="dashboard">
								<ul class="nav nav-collapse">
									<li>
										<a href="<?= $link; ?>/admin/konfigurasi-panel">
											<span class="sub-item">Konfigurasi Panel</span>
										</a>
									</li>
									<li>
										<a href="<?= $link; ?>/admin/isi-saldo">
											<span class="sub-item">Isi Saldo</span>
										</a>
									</li>
									<li>
										<a href="<?= $link; ?>/admin/kelola-pembelian">
											<span class="sub-item">Kelola Pembelian</span>
										</a>
									</li>
									<li>
										<a href="<?= $link; ?>/admin/kelola-pengguna">
											<span class="sub-item">Kelola Pengguna</span>
										</a>
									</li>
									<li>
										<a href="<?= $link; ?>/admin/kelola-layanan">
											<span class="sub-item">Kelola Layanan</span>
										</a>
									</li>
									<li>
										<a href="<?= $link; ?>/admin/kelola-kontak">
											<span class="sub-item">Kelola Kontak</span>
										</a>
									</li>
								</ul>
							</div>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/pembelian-baru">
								<i class="fas fa-shopping-cart"></i>
								<p>Pembelian Baru</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/riwayat-pembelian">
								<i class="fas fa-history"></i>
								<p>Riwayat Pembelian</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/riwayat-saldo">
								<i class="fas fa-money-bill"></i>
								<p>Riwayat Saldo</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/daftar-layanan">
								<i class="fas fa-tag"></i>
								<p>Daftar Layanan</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/pengaturan-akun">
								<i class="fas fa-cog"></i>
								<p>Pengaturan Akun</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= $link; ?>/kontak-kami">
								<i class="fas fa-users"></i>
								<p>Kontak Kami</p>
							</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<!-- End Sidebar -->
