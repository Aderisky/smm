<?php
$judul = "GPU";
?>