			<footer class="footer">
				<div class="footer-bottom container-fluid">
					<nav class="pull-left">
						Copyright &copy; 2019 <?= $judul; ?> - All right reserved.
					</nav>			
				</div>
			</footer>