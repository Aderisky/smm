<?php
$password_db = "admin";
$hal_db = "on";
?>