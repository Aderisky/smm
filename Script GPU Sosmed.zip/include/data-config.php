<?php
	$db = mysqli_connect("localhost", "root", "", "panel_sosmed");
	$link = "http://localhost/_11-november-2019/smm-free-v3";
	$localhost = "localhost";
	$username = "root";
	$password = "";
	$database = "panel_sosmed";
	?>